const express = require("express");
const fs = require("node:fs");
const path = require("node:path");

const app = express();

const PORT = 3002;
const GATEWAY_TOKEN = "cms3407-gateway-token";
const DATA_FILE = path.join(__dirname, "data", "customers.json");


app.use(express.json());


function readData() {
    const file = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(file);
}

function saveData(records) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2));
}

app.use(function (req, res, next) {
    if (req.headers["x-gateway-token"] !== GATEWAY_TOKEN) {
        return res.status(403).json({
            error: "Please access this service through the API Gateway"
        });
    }

    next();
});

function validateCustomer(customer) {
    if (!customer || typeof customer !== "object" || Array.isArray(customer)) {
        return "Customer information must be a JSON object";
    }

    if (!customer.fullName || !customer.email ||
        !customer.phone || !customer.address) {
        return "Name, email, phone and address are required";
    }

    if (!customer.email.includes("@") || !customer.email.includes(".")) {
        return "Please enter a valid email address";
    }

    return null;
}

app.get("/customers", function (req, res) {
    const customers = readData();
    res.json({ data: customers });
});


app.get("/customers/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Customer ID must be a number" });
    }

    const customers = readData();
    const customer = customers.find(function (item) {
        return item.id === id;
    });

    if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
    }

    res.json({ data: customer });
});


app.post("/customers", function (req, res) {
    const problem = validateCustomer(req.body);

    if (problem) {
        return res.status(400).json({ error: problem });
    }

    const customers = readData();

    const newId = customers.length
        ? Math.max(...customers.map(function (item) { return item.id; })) + 1
        : 2001;

    const newCustomer = {
        id: newId,
        fullName: req.body.fullName,
        email: req.body.email,
        phone: req.body.phone,
        address: req.body.address
    };

    customers.push(newCustomer);
    saveData(customers);

    res.status(201).json({
        message: "Customer added",
        data: newCustomer
    });
});


app.put("/customers/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Customer ID must be a number" });
    }

    const problem = validateCustomer(req.body);

    if (problem) {
        return res.status(400).json({ error: problem });
    }

    const customers = readData();
    const index = customers.findIndex(function (item) {
        return item.id === id;
    });

    if (index === -1) {
        return res.status(404).json({ error: "Customer not found" });
    }

    const updatedCustomer = {
        id: id,
        fullName: req.body.fullName,
        email: req.body.email,
        phone: req.body.phone,
        address: req.body.address
    };

    customers[index] = updatedCustomer;
    saveData(customers);

    res.json({
        message: "Customer updated",
        data: updatedCustomer
    });
});


app.delete("/customers/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Customer ID must be a number" });
    }

    const customers = readData();
    const index = customers.findIndex(function (item) {
        return item.id === id;
    });

    if (index === -1) {
        return res.status(404).json({ error: "Customer not found" });
    }

    const deletedCustomer = customers.splice(index, 1)[0];
    saveData(customers);

    res.json({
        message: "Customer deleted",
        data: deletedCustomer
    });
});


app.all("/customers", function (req, res) {
    res.status(405).json({ error: "Method not allowed" });
});

app.all("/customers/:id", function (req, res) {
    res.status(405).json({ error: "Method not allowed" });
});



app.use(function (req, res) {
    res.status(404).json({
        error: "Customer Service route not found"
    });
});

app.use(function (error, req, res, next) {
    res.status(400).json({
        error: "Invalid JSON"
    });
});

app.listen(PORT, "127.0.0.1", function () {
    console.log("Customer Service is running on port " + PORT);
});
