
module.exports = require("./gatewayRoutes");
