// Load the Gateway routes.
module.exports = require("./gatewayRoutes");
