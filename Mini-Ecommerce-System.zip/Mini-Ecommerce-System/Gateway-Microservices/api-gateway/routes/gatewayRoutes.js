const express = require("express");
const http = require("node:http");

const router = express.Router();


const services = [
    {
        clientRoute: "/api/products",
        backendRoute: "/products",
        backendPort: 3001,
        serviceName: "Product Management Service"
    },
    {
        clientRoute: "/api/customers",
        backendRoute: "/customers",
        backendPort: 3002,
        serviceName: "Customer Management Service"
    },
    {
        clientRoute: "/api/orders",
        backendRoute: "/orders",
        backendPort: 3003,
        serviceName: "Order Management Service"
    }
];

const GATEWAY_TOKEN = "cms3407-gateway-token";


function sendToService(req, res, service) {

    const backendPath = req.originalUrl.replace(
        service.clientRoute,
        service.backendRoute
    );


    let requestBody = null;

    if (req.body && Object.keys(req.body).length > 0) {
        requestBody = JSON.stringify(req.body);
    }

    const requestHeaders = {
        "Content-Type": "application/json",
        "x-gateway-token": GATEWAY_TOKEN
    };

    if (requestBody) {
        requestHeaders["Content-Length"] = Buffer.byteLength(requestBody);
    }


    const backendRequest = http.request({
        hostname: "127.0.0.1",
        port: service.backendPort,
        path: backendPath,
        method: req.method,
        headers: requestHeaders
    }, function (backendResponse) {


        res.status(backendResponse.statusCode || 502);
        res.set(
            "Content-Type",
            backendResponse.headers["content-type"] || "application/json"
        );

        backendResponse.pipe(res);
    });


    backendRequest.setTimeout(5000, function () {
        backendRequest.destroy(new Error("Backend request timed out"));
    });

    backendRequest.on("error", function () {
        if (!res.headersSent) {
            res.status(502).json({
                error: service.serviceName + " is not available"
            });
        }
    });


    backendRequest.end(requestBody);
}


router.get("/health", function (req, res) {
    res.json({
        message: "API Gateway is running"
    });
});


services.forEach(function (service) {
    router.use(service.clientRoute, function (req, res) {
        sendToService(req, res, service);
    });
});


router.use(function (req, res) {
    res.status(404).json({
        error: "Gateway route not found"
    });
});


module.exports = router;
