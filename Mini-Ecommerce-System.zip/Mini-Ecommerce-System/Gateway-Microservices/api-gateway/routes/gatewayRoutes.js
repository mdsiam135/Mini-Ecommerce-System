const express = require("express");
const http = require("node:http");

const router = express.Router();

// These are the three backend services.
const services = [
    {
        clientRoute: "/api/products",
        backendRoute: "/products",
        backendPort: 3001,
        serviceName: "Product Management Service"
    },
    {
        clientRoute: "/api/customers",
        backendRoute: "/customers",
        backendPort: 3002,
        serviceName: "Customer Management Service"
    },
    {
        clientRoute: "/api/orders",
        backendRoute: "/orders",
        backendPort: 3003,
        serviceName: "Order Management Service"
    }
];

const GATEWAY_TOKEN = "cms3407-gateway-token";

// Forward a client request to the correct microservice.
function sendToService(req, res, service) {

    // Change the Gateway route into the backend route.
    const backendPath = req.originalUrl.replace(
        service.clientRoute,
        service.backendRoute
    );

    // Convert the request body into JSON.
    let requestBody = null;

    if (req.body && Object.keys(req.body).length > 0) {
        requestBody = JSON.stringify(req.body);
    }

    // Prepare the headers for the backend service.
    const requestHeaders = {
        "Content-Type": "application/json",
        "x-gateway-token": GATEWAY_TOKEN
    };

    if (requestBody) {
        requestHeaders["Content-Length"] = Buffer.byteLength(requestBody);
    }

    // Send the request to the backend service.
    const backendRequest = http.request({
        hostname: "127.0.0.1",
        port: service.backendPort,
        path: backendPath,
        method: req.method,
        headers: requestHeaders
    }, function (backendResponse) {

        // Return the backend response to the client.
        res.status(backendResponse.statusCode || 502);
        res.set(
            "Content-Type",
            backendResponse.headers["content-type"] || "application/json"
        );

        backendResponse.pipe(res);
    });

    // Stop waiting if the backend does not respond within five seconds.
    backendRequest.setTimeout(5000, function () {
        backendRequest.destroy(new Error("Backend request timed out"));
    });

    // Return an error if the backend service is unavailable.
    backendRequest.on("error", function () {
        if (!res.headersSent) {
            res.status(502).json({
                error: service.serviceName + " is not available"
            });
        }
    });

    // Send the request body, if one exists.
    backendRequest.end(requestBody);
}

// Gateway health check.
router.get("/health", function (req, res) {
    res.json({
        message: "API Gateway is running"
    });
});

// Connect each Gateway route to its microservice.
services.forEach(function (service) {
    router.use(service.clientRoute, function (req, res) {
        sendToService(req, res, service);
    });
});

// Handle routes that do not exist.
router.use(function (req, res) {
    res.status(404).json({
        error: "Gateway route not found"
    });
});

// Make the Router available to server.js.
module.exports = router;
