const express = require("express");
const routes = require("./routes");

const app = express();
const PORT = 3000;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/", routes);

// // Handle invalid JSON requests.
// app.use(function (error, req, res, next) {
//     res.status(400).json({
//         error: "Invalid JSON or request body"
//     });
// });


app.use(function (error, req, res, next) {

    console.error("Gateway Error:", error.message);
    console.error("Error Type:", error.type);

    res.status(error.status || 500).json({
        error: error.message || "Internal Server Error"
    });
});


app.listen(PORT, function () {
    console.log("Gateway is running on port " + PORT + ".");
});
