const express = require("express");
const fs = require("node:fs");
const path = require("node:path");

const app = express();

const PORT = 3003;
const GATEWAY_TOKEN = "cms3407-gateway-token";
const DATA_FILE = path.join(__dirname, "data", "orders.json");

app.use(express.json());


function readData() {
    const file = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(file);
}

function saveData(records) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2));
}


app.use(function (req, res, next) {
    if (req.headers["x-gateway-token"] !== GATEWAY_TOKEN) {
        return res.status(403).json({
            error: "Please access this service through the API Gateway"
        });
    }

    next();
});

function validateOrder(order) {
    if (!order || typeof order !== "object" || Array.isArray(order)) {
        return "Order information must be a JSON object";
    }

    if (!Number.isInteger(order.customerId) || order.customerId < 1) {
        return "Customer ID must be a positive number";
    }

    if (!Number.isInteger(order.productId) || order.productId < 1) {
        return "Product ID must be a positive number";
    }

    if (!Number.isInteger(order.quantity) || order.quantity < 1) {
        return "Quantity must be at least 1";
    }

    if (typeof order.unitPrice !== "number" || order.unitPrice <= 0) {
        return "Unit price must be greater than zero";
    }

    if (order.status !== undefined &&
        !["Pending", "Processing", "Shipped", "Delivered", "Cancelled"].includes(order.status)) {
        return "Order status is not valid";
    }

    return null;
}


app.get("/orders", function (req, res) {
    const orders = readData();
    res.json({ data: orders });
});


app.get("/orders/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Order ID must be a number" });
    }

    const orders = readData();
    const order = orders.find(function (item) {
        return item.id === id;
    });

    if (!order) {
        return res.status(404).json({ error: "Order not found" });
    }

    res.json({ data: order });
});


app.post("/orders", function (req, res) {
    const problem = validateOrder(req.body);

    if (problem) {
        return res.status(400).json({ error: problem });
    }

    const orders = readData();

    const newId = orders.length
        ? Math.max(...orders.map(function (item) { return item.id; })) + 1
        : 3001;

    const newOrder = {
        id: newId,
        customerId: req.body.customerId,
        productId: req.body.productId,
        quantity: req.body.quantity,
        unitPrice: req.body.unitPrice,
        totalPrice: Number((req.body.quantity * req.body.unitPrice).toFixed(2)),
        status: req.body.status || "Pending"
    };

    orders.push(newOrder);
    saveData(orders);

    res.status(201).json({
        message: "Order added",
        data: newOrder
    });
});

app.put("/orders/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Order ID must be a number" });
    }

    const problem = validateOrder(req.body);

    if (problem) {
        return res.status(400).json({ error: problem });
    }

    const orders = readData();
    const index = orders.findIndex(function (item) {
        return item.id === id;
    });

    if (index === -1) {
        return res.status(404).json({ error: "Order not found" });
    }

    const updatedOrder = {
        id: id,
        customerId: req.body.customerId,
        productId: req.body.productId,
        quantity: req.body.quantity,
        unitPrice: req.body.unitPrice,
        totalPrice: Number((req.body.quantity * req.body.unitPrice).toFixed(2)),
        status: req.body.status || "Pending"
    };

    orders[index] = updatedOrder;
    saveData(orders);

    res.json({
        message: "Order updated",
        data: updatedOrder
    });
});


app.delete("/orders/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Order ID must be a number" });
    }

    const orders = readData();
    const index = orders.findIndex(function (item) {
        return item.id === id;
    });

    if (index === -1) {
        return res.status(404).json({ error: "Order not found" });
    }

    const deletedOrder = orders.splice(index, 1)[0];
    saveData(orders);

    res.json({
        message: "Order deleted",
        data: deletedOrder
    });
});


app.all("/orders", function (req, res) {
    res.status(405).json({ error: "Method not allowed" });
});

app.all("/orders/:id", function (req, res) {
    res.status(405).json({ error: "Method not allowed" });
});



app.use(function (req, res) {
    res.status(404).json({
        error: "Order Service route not found"
    });
});

app.use(function (error, req, res, next) {
    res.status(400).json({
        error: "Invalid JSON"
    });
});


app.listen(PORT, "127.0.0.1", function () {
    console.log("Order Service is running on port " + PORT);
});
