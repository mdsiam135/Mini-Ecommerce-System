const express = require("express");
const fs = require("node:fs");
const path = require("node:path");

const app = express();

const PORT = 3001;
const GATEWAY_TOKEN = "cms3407-gateway-token";
const DATA_FILE = path.join(__dirname, "data", "products.json");

// Read JSON sent by the client.
app.use(express.json());

// Read records from the JSON database.
function readData() {
    const file = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(file);
}

// Save records in the JSON database.
function saveData(records) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2));
}

// Only accept requests that come through the API Gateway.
app.use(function (req, res, next) {
    if (req.headers["x-gateway-token"] !== GATEWAY_TOKEN) {
        return res.status(403).json({
            error: "Please access this service through the API Gateway"
        });
    }

    next();
});

// Check the information before saving it.

function validateProduct(product) {
    if (!product || typeof product !== "object" || Array.isArray(product)) {
        return "Product information must be a JSON object";
    }

    if (!product.name || !product.category) {
        return "Product name and category are required";
    }

    if (typeof product.price !== "number" || product.price <= 0) {
        return "Price must be greater than zero";
    }

    if (!Number.isInteger(product.stock) || product.stock < 0) {
        return "Stock must be zero or a positive whole number";
    }

    return null;
}


// ---------------- HTTP ROUTES ----------------


// GET: show all products.
app.get("/products", function (req, res) {
    const products = readData();
    res.json({ data: products });
});

// GET: show one product.
app.get("/products/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Product ID must be a number" });
    }

    const products = readData();
    const product = products.find(function (item) {
        return item.id === id;
    });

    if (!product) {
        return res.status(404).json({ error: "Product not found" });
    }

    res.json({ data: product });
});

// POST: add a new product.
app.post("/products", function (req, res) {
    const problem = validateProduct(req.body);

    if (problem) {
        return res.status(400).json({ error: problem });
    }

    const products = readData();

    const newId = products.length
        ? Math.max(...products.map(function (item) { return item.id; })) + 1
        : 1001;

    const newProduct = {
        id: newId,
        name: req.body.name,
        category: req.body.category,
        price: req.body.price,
        stock: req.body.stock
    };

    products.push(newProduct);
    saveData(products);

    res.status(201).json({
        message: "Product added",
        data: newProduct
    });
});

// PUT: update an existing product.
app.put("/products/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Product ID must be a number" });
    }

    const problem = validateProduct(req.body);

    if (problem) {
        return res.status(400).json({ error: problem });
    }

    const products = readData();
    const index = products.findIndex(function (item) {
        return item.id === id;
    });

    if (index === -1) {
        return res.status(404).json({ error: "Product not found" });
    }

    const updatedProduct = {
        id: id,
        name: req.body.name,
        category: req.body.category,
        price: req.body.price,
        stock: req.body.stock
    };

    products[index] = updatedProduct;
    saveData(products);

    res.json({
        message: "Product updated",
        data: updatedProduct
    });
});

// DELETE: remove a product.
app.delete("/products/:id", function (req, res) {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: "Product ID must be a number" });
    }

    const products = readData();
    const index = products.findIndex(function (item) {
        return item.id === id;
    });

    if (index === -1) {
        return res.status(404).json({ error: "Product not found" });
    }

    const deletedProduct = products.splice(index, 1)[0];
    saveData(products);

    res.json({
        message: "Product deleted",
        data: deletedProduct
    });
});

// Return 405 for methods that are not supported.
app.all("/products", function (req, res) {
    res.status(405).json({ error: "Method not allowed" });
});

app.all("/products/:id", function (req, res) {
    res.status(405).json({ error: "Method not allowed" });
});


// Return 404 if the service route does not exist.
app.use(function (req, res) {
    res.status(404).json({
        error: "Product Service route not found"
    });
});

// Return an error if the client sends invalid JSON.
app.use(function (error, req, res, next) {
    res.status(400).json({
        error: "Invalid JSON"
    });
});

// Start the microservice.
app.listen(PORT, "127.0.0.1", function () {
    console.log("Product Service is running on port " + PORT);
});
