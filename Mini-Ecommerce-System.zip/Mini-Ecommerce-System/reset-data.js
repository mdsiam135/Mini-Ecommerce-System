const fs = require("node:fs");
const path = require("node:path");

const folder = path.join(__dirname, "Gateway-Microservices");

// Original product data.
const products = [
    { id: 1001, name: "Wireless Mouse", category: "Electronics", price: 15.99, stock: 50 },
    { id: 1002, name: "Mechanical Keyboard", category: "Electronics", price: 49.99, stock: 20 },
    { id: 1003, name: "USB-C Hub", category: "Accessories", price: 29.50, stock: 35 }
];

// Original customer data.
const customers = [
    { id: 2001, fullName: "Alice Johnson", email: "alice@example.com", phone: "07123456789", address: "London" },
    { id: 2002, fullName: "David Brown", email: "david@example.com", phone: "07987654321", address: "Manchester" }
];

// Original order data.
const orders = [
    { id: 3001, customerId: 2001, productId: 1001, quantity: 2, unitPrice: 15.99, totalPrice: 31.98, status: "Pending" },
    { id: 3002, customerId: 2002, productId: 1002, quantity: 1, unitPrice: 49.99, totalPrice: 49.99, status: "Processing" }
];

// Restore the original JSON files.
fs.writeFileSync(
    path.join(folder, "product-service/data/products.json"),
    JSON.stringify(products, null, 2)
);

fs.writeFileSync(
    path.join(folder, "customer-service/data/customers.json"),
    JSON.stringify(customers, null, 2)
);

fs.writeFileSync(
    path.join(folder, "order-service/data/orders.json"),
    JSON.stringify(orders, null, 2)
);

console.log("The three JSON databases have been reset.");
