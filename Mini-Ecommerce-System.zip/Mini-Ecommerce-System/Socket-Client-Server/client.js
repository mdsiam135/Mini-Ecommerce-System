const net = require("node:net");

const PORT = 4000;

// Connect to the socket server.
const client = net.createConnection(
    { host: "127.0.0.1", port: PORT },
    function () {
        console.log("Connected to the server.");

        // Send a message to the server.
        client.write("Hello server. This is the client.");
    }
);

// Receive the server's reply.
client.on("data", function (message) {
    console.log("Server says:", message.toString());
    client.end();
});

// Show an error if the server is not running.
client.on("error", function (error) {
    console.log("Connection error:", error.message);
});
