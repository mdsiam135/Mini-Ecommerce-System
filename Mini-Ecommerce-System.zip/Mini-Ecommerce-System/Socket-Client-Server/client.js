const net = require("node:net");

const PORT = 4000;

const client = net.createConnection(
    { host: "127.0.0.1", port: PORT },
    function () {
        console.log("Connected to the server.");
        client.write("Hello server. This is the client.");
    }
);

client.on("data", function (message) {
    console.log("Server says:", message.toString());
    client.end();
});

client.on("error", function (error) {
    console.log("Connection error:", error.message);
});
