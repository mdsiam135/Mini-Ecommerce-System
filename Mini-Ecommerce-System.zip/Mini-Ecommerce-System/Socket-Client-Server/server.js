const net = require("node:net");

const PORT = 4000;


const server = net.createServer(function (client) {
    console.log("A client connected.");

    client.on("data", function (message) {
        console.log("Client says:", message.toString());

        client.write("Hello client. I received your message.");
    });

    client.on("end", function () {
        console.log("Client disconnected.");
    });
});

server.listen(PORT, "127.0.0.1", function () {
    console.log("Socket server is running on port " + PORT);
});
