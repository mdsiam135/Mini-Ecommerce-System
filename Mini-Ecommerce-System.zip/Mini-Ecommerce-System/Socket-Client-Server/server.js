const net = require("node:net");

const PORT = 4000;

// Create the socket server.
const server = net.createServer(function (client) {
    console.log("A client connected.");

    // Receive a message from the client.
    client.on("data", function (message) {
        console.log("Client says:", message.toString());

        // Send a reply to the client.
        client.write("Hello client. I received your message.");
    });

    client.on("end", function () {
        console.log("Client disconnected.");
    });
});

// Start the socket server.
server.listen(PORT, "127.0.0.1", function () {
    console.log("Socket server is running on port " + PORT);
});
